/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      fontFamily: {
        sans: ['Space Grotesk', 'system-ui', 'sans-serif'],
        mono: ['JetBrains Mono', 'ui-monospace', 'monospace'],
      },
      colors: {
        ink: {
          950: '#05070b',
          900: '#080b12',
          850: '#0b0f17',
          800: '#0e131d',
          700: '#141a26',
          600: '#1c2433',
          500: '#273142',
          400: '#3a4658',
          300: '#5a6878',
        },
        aqua: {
          400: '#5eead4',
          500: '#2dd4bf',
          600: '#14b8a6',
          700: '#0d9488',
        },
        ember: {
          400: '#fbbf24',
          500: '#f59e0b',
          600: '#d97706',
        },
        rust: {
          400: '#fb7185',
          500: '#f43f5e',
          600: '#e11d48',
        },
      },
      keyframes: {
        'fade-up': {
          '0%': { opacity: '0', transform: 'translateY(12px)' },
          '100%': { opacity: '1', transform: 'translateY(0)' },
        },
        'fade-in': {
          '0%': { opacity: '0' },
          '100%': { opacity: '1' },
        },
        'scan-sweep': {
          '0%': { transform: 'translateX(-100%)' },
          '100%': { transform: 'translateX(100%)' },
        },
        'pulse-ring': {
          '0%': { transform: 'scale(0.6)', opacity: '0.6' },
          '100%': { transform: 'scale(2.4)', opacity: '0' },
        },
        'rise-glow': {
          '0%, 100%': { opacity: '0.4' },
          '50%': { opacity: '0.9' },
        },
        'wave-drift': {
          '0%': { backgroundPosition: '0% 50%' },
          '100%': { backgroundPosition: '100% 50%' },
        },
      },
      animation: {
        'fade-up': 'fade-up 0.8s cubic-bezier(0.22, 1, 0.36, 1) both',
        'fade-in': 'fade-in 1s ease both',
        'scan-sweep': 'scan-sweep 2.4s ease-in-out infinite',
        'pulse-ring': 'pulse-ring 2.8s ease-out infinite',
        'rise-glow': 'rise-glow 4s ease-in-out infinite',
        'wave-drift': 'wave-drift 8s linear infinite',
      },
    },
  },
  plugins: [],
};
