import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  Activity,
  Layers,
  MapPin,
  Play,
  Radio,
  Waves,
  Mountain,
  Crosshair,
  ArrowDownToLine,
  Database,
  Cpu,
  GitCompareArrows,
} from 'lucide-react';

import { generateSeismogram, decimate, type Trace, type WaveParams } from '@/engine/waveform';
import { processTrace, detectArrivals, type Arrival, type ProcessedTrace } from '@/engine/processing';
import { reconstructVelocity, type VelocityMap, type VeinCandidate, type RegionSpec } from '@/engine/tomography';
import { REGION_PRESETS } from '@/components/presets';
import WaveformCanvas from '@/components/WaveformCanvas';
import VelocityMapCanvas from '@/components/VelocityMapCanvas';
import TrainingCurve from '@/components/TrainingCurve';
import PipelineRail, { type StageState } from '@/components/PipelineRail';

type AppState = 'idle' | 'processing' | 'complete';

export default function App() {
  const [state, setState] = useState<AppState>('idle');
  const [magnitude, setMagnitude] = useState(4.6);
  const [distanceKm, setDistanceKm] = useState(12);
  const [rockType, setRockType] = useState<WaveParams['rockType']>('ore_host');
  const [regionId, setRegionId] = useState(REGION_PRESETS[0].id);
  const region = useMemo<RegionSpec>(
    () => {
      const p = REGION_PRESETS.find((r) => r.id === regionId) ?? REGION_PRESETS[0];
      return {
        id: p.id,
        name: p.name,
        widthKm: p.widthKm,
        depthKm: p.depthKm,
        cols: 64,
        rows: 40,
        baseRock: p.baseRock,
      };
    },
    [regionId],
  );

  const [trace, setTrace] = useState<Trace | null>(null);
  const [processed, setProcessed] = useState<ProcessedTrace | null>(null);
  const [arrivals, setArrivals] = useState<Arrival[]>([]);
  const [velocityMap, setVelocityMap] = useState<VelocityMap | null>(null);
  const [selected, setSelected] = useState<VeinCandidate | null>(null);

  // Animation progress values for each stage reveal.
  const [waveProgress, setWaveProgress] = useState(0);
  const [denoiseProgress, setDenoiseProgress] = useState(0);
  const [envProgress, setEnvProgress] = useState(0);
  const [mapProgress, setMapProgress] = useState(0);

  // Stage labels for the pipeline rail.
  const [stages, setStages] = useState<{ id: string; label: string; sub: string; state: StageState }[]>([
    { id: 'acquire', label: 'Waveform acquisition', sub: 'Local earthquake seismogram (STEAD-style record)', state: 'pending' },
    { id: 'denoise', label: 'Denoise & bandpass', sub: 'DAS-style preprocessing — remove microseismic noise', state: 'pending' },
    { id: 'detect', label: 'Event / reflection detection', sub: 'Envelope picking of P, S, surface & reflection phases', state: 'pending' },
    { id: 'tomography', label: 'Velocity reconstruction', sub: 'Travel-time inversion -> 2-D seismic-velocity map', state: 'pending' },
    { id: 'classify', label: 'CNN training + classification', sub: 'Conv-Net trains on labelled velocity patches, then scans the map', state: 'pending' },
  ]);

  const animRef = useRef<{ cancel: () => void } | null>(null);

  // Smoothly animate a numeric value from 0 -> 1 over a duration, then resolve.
  const animateTo = useCallback((durationMs: number, onTick: (t: number) => void) => {
    return new Promise<void>((resolve) => {
      const start = performance.now();
      let raf = 0;
      const tick = (now: number) => {
        const t = Math.min(1, (now - start) / durationMs);
        const eased = 1 - Math.pow(1 - t, 3);
        onTick(eased);
        if (t < 1) raf = requestAnimationFrame(tick);
        else resolve();
      };
      raf = requestAnimationFrame(tick);
      animRef.current = { cancel: () => cancelAnimationFrame(raf) };
    });
  }, []);

  const setStage = (i: number, st: StageState) => {
    setStages((prev) => prev.map((s, idx) => (idx === i ? { ...s, state: st } : s)));
  };

  const runPipeline = useCallback(async () => {
    if (animRef.current) animRef.current.cancel();
    setSelected(null);
    setState('processing');
    setWaveProgress(0);
    setDenoiseProgress(0);
    setEnvProgress(0);
    setMapProgress(0);
    setStages((prev) => prev.map((s) => ({ ...s, state: 'pending' as StageState })));

    const sr = 100;
    const duration = 16;
    const params: WaveParams = { magnitude, distanceKm, rockType, samplingRate: sr, durationS: duration };

    // 1. Acquire waveform.
    setStage(0, 'active');
    const tr = generateSeismogram(params);
    setTrace(tr);
    await animateTo(2200, (t) => setWaveProgress(t));
    setStage(0, 'done');

    // 2. Denoise.
    setStage(1, 'active');
    const p = processTrace(tr);
    setProcessed(p);
    await animateTo(2000, (t) => setDenoiseProgress(t));
    setStage(1, 'done');

    // 3. Event / reflection detection.
    setStage(2, 'active');
    const arr = detectArrivals(p);
    setArrivals(arr);
    await animateTo(1800, (t) => setEnvProgress(t));
    setStage(2, 'done');

    // 4. Velocity reconstruction.
    setStage(3, 'active');
    const seed = Math.floor(magnitude * 1000) + distanceKm * 31 + rockType.length * 7 + regionId.length * 13;
    const vmap = reconstructVelocity(region, arr, seed);
    setVelocityMap(vmap);
    await animateTo(2600, (t) => setMapProgress(t));
    setStage(3, 'done');

    // 5. CNN classification.
    setStage(4, 'active');
    await animateTo(1600, () => {});
    setStage(4, 'done');

    setState('complete');
  }, [magnitude, distanceKm, rockType, region, animateTo, regionId]);

  const displayRaw = useMemo(() => (trace ? decimate(trace, 900) : []), [trace]);
  const displayDenoised = useMemo(() => (processed ? downsample(processed.denoised, 900) : []), [processed]);
  const displayEnvelope = useMemo(() => (processed ? downsample(processed.envelope, 900) : []), [processed]);

  const primaryVein = velocityMap?.candidates.find((c) => c.status === 'primary') ?? null;

  return (
    <div className="min-h-screen text-slate-200">
      <BackdropParticles />

      <header className="relative z-10 border-b border-white/5">
        <div className="max-w-7xl mx-auto px-6 py-5 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-aqua-500/30 to-rust-500/20 border border-white/10 flex items-center justify-center">
              <Waves className="w-5 h-5 text-aqua-400" />
            </div>
            <div>
              <div className="text-sm font-semibold tracking-tight text-white">SeismoReveal</div>
              <div className="label-eyebrow">Subsurface Ore-Vein Imaging Console</div>
            </div>
          </div>
          <div className="hidden md:flex items-center gap-6 label-eyebrow">
            <span className="flex items-center gap-2">
              <span className="w-1.5 h-1.5 rounded-full bg-aqua-400 animate-pulse" />
              Seismic channel online
            </span>
            <span>v0.9 · research build</span>
          </div>
        </div>
      </header>

      <main className="relative z-10 max-w-7xl mx-auto px-6 py-10 space-y-8">
        {/* Hero */}
        <section className="animate-fade-up">
          <div className="flex flex-col md:flex-row md:items-end md:justify-between gap-6">
            <div className="max-w-2xl">
              <div className="label-eyebrow mb-3 flex items-center gap-2">
                <Radio className="w-3.5 h-3.5" /> Passive-source seismic imaging
              </div>
              <h1 className="text-4xl md:text-5xl font-semibold tracking-tight text-white leading-[1.05]">
                Using earthquake waves
                <br />
                <span className="text-aqua-400 text-glow-aqua">to detect ore veins.</span>
              </h1>
              <p className="mt-5 text-slate-400 text-[15px] leading-relaxed max-w-xl">
                Feed a recorded earthquake waveform into the console. The pipeline denoises the
                signal, picks arrival and reflection events, reconstructs a 2-D seismic-velocity
                cross-section, and runs a convolutional scan for high-velocity anomalies that may
                mark buried mineral veins.
              </p>
            </div>
            <div className="flex items-center gap-4">
              <ReferenceBadges />
            </div>
          </div>
        </section>

        {/* Control deck */}
        <section className="panel p-6 animate-fade-up" style={{ animationDelay: '120ms' }}>
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            <div className="lg:col-span-5 space-y-5">
              <SectionLabel icon={<Activity className="w-4 h-4" />} title="Earthquake source" />
              <Slider
                label="Moment magnitude"
                value={magnitude}
                min={3}
                max={6.5}
                step={0.1}
                unit="Mw"
                onChange={setMagnitude}
                accent="rust"
              />
              <Slider
                label="Receiver distance"
                value={distanceKm}
                min={2}
                max={28}
                step={1}
                unit="km"
                onChange={setDistanceKm}
                accent="aqua"
              />
              <div>
                <div className="text-xs text-slate-400 mb-2">Host medium</div>
                <div className="grid grid-cols-3 gap-2">
                  {(['sediment', 'basalt', 'granite', 'ore_host'] as const).map((r) => (
                    <button
                      key={r}
                      onClick={() => setRockType(r)}
                      className={`px-3 py-2 rounded-lg text-xs font-medium border transition-all duration-300 ${
                        rockType === r
                          ? 'border-aqua-500/50 bg-aqua-500/10 text-aqua-300'
                          : 'border-white/5 bg-white/[0.02] text-slate-400 hover:border-white/10'
                      }`}
                    >
                      {r === 'ore_host' ? 'Ore host' : r.charAt(0).toUpperCase() + r.slice(1)}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            <div className="lg:col-span-5 space-y-5">
              <SectionLabel icon={<MapPin className="w-4 h-4" />} title="Survey region" />
              <div className="space-y-2">
                {REGION_PRESETS.map((r) => (
                  <button
                    key={r.id}
                    onClick={() => setRegionId(r.id)}
                    className={`w-full text-left px-4 py-3 rounded-xl border transition-all duration-300 ${
                      regionId === r.id
                        ? 'border-aqua-500/40 bg-aqua-500/[0.07]'
                        : 'border-white/5 bg-white/[0.02] hover:border-white/10'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-medium text-white">{r.name}</span>
                      <span className="label-eyebrow">
                        {r.widthKm}×{r.depthKm}km · {r.baseRock}
                      </span>
                    </div>
                    <div className="text-xs text-slate-500 mt-1">{r.description}</div>
                  </button>
                ))}
              </div>
            </div>

            <div className="lg:col-span-2 flex flex-col justify-between">
              <SectionLabel icon={<Cpu className="w-4 h-4" />} title="Run" />
              <div className="flex flex-col gap-3">
                <div className="panel-tight p-3">
                  <div className="label-eyebrow">Pipeline</div>
                  <div className="text-xs text-slate-400 mt-1 leading-relaxed">5 stages, ~10s sim</div>
                </div>
                <button
                  onClick={runPipeline}
                  disabled={state === 'processing'}
                  className="group relative w-full px-4 py-3.5 rounded-xl bg-gradient-to-br from-aqua-500 to-aqua-700 text-ink-950 font-semibold text-sm flex items-center justify-center gap-2 disabled:opacity-60 disabled:cursor-not-allowed hover:shadow-[0_0_30px_-8px_rgba(45,212,191,0.6)] transition-all duration-300"
                >
                  <Play className="w-4 h-4 group-disabled:animate-none" />
                  {state === 'processing' ? 'Imaging…' : state === 'complete' ? 'Re-run scan' : 'Begin scan'}
                </button>
              </div>
            </div>
          </div>
        </section>

        {/* Pipeline + waveform stage */}
        <section className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          <div className="lg:col-span-4">
            <div className="panel p-5 h-full">
              <SectionLabel icon={<GitCompareArrows className="w-4 h-4" />} title="Processing pipeline" />
              <div className="mt-4">
                <PipelineRail stages={stages} />
              </div>
            </div>
          </div>

          <div className="lg:col-span-8 space-y-6">
            {/* Raw waveform */}
            <div className="panel p-5">
              <div className="flex items-center justify-between mb-3">
                <SectionLabel icon={<Radio className="w-4 h-4" />} title="1 · Raw seismogram" />
                <span className="label-eyebrow">{trace ? `${trace.samplingRate} Hz · ${trace.durationS}s` : 'awaiting input'}</span>
              </div>
              <div className="panel-tight p-3 grid-backdrop rounded-xl overflow-hidden">
                {trace ? (
                  <WaveformCanvas
                    data={displayRaw}
                    sampleRate={trace.samplingRate}
                    durationS={trace.durationS}
                    arrivals={[]}
                    variant="raw"
                    progress={waveProgress}
                    height={110}
                  />
                ) : (
                  <EmptyWaveform label="No waveform yet — press Begin scan" />
                )}
              </div>
            </div>

            {/* Denoised + envelope */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="panel p-5">
                <div className="flex items-center justify-between mb-3">
                  <SectionLabel icon={<Waves className="w-4 h-4" />} title="2 · Denoised bandpass" />
                  <span className="label-eyebrow">1.2–18 Hz</span>
                </div>
                <div className="panel-tight p-3 grid-backdrop rounded-xl overflow-hidden">
                  {processed ? (
                    <WaveformCanvas
                      data={displayDenoised}
                      sampleRate={processed.samplingRate}
                      durationS={trace!.durationS}
                      arrivals={[]}
                      variant="denoised"
                      progress={denoiseProgress}
                      height={110}
                    />
                  ) : (
                    <EmptyWaveform />
                  )}
                </div>
              </div>
              <div className="panel p-5">
                <div className="flex items-center justify-between mb-3">
                  <SectionLabel icon={<Activity className="w-4 h-4" />} title="3 · Envelope & picks" />
                  <span className="label-eyebrow">{arrivals.length} events</span>
                </div>
                <div className="panel-tight p-3 grid-backdrop rounded-xl overflow-hidden">
                  {processed ? (
                    <WaveformCanvas
                      data={displayEnvelope}
                      sampleRate={processed.samplingRate}
                      durationS={trace!.durationS}
                      arrivals={arrivals}
                      variant="envelope"
                      progress={envProgress}
                      height={110}
                    />
                  ) : (
                    <EmptyWaveform />
                  )}
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Velocity map + results */}
        <section className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          <div className="lg:col-span-8">
            <div className="panel p-5">
              <div className="flex items-center justify-between mb-3">
                <SectionLabel icon={<Layers className="w-4 h-4" />} title="4 · Subsurface velocity reconstruction" />
                <span className="label-eyebrow">{region.name} · {region.widthKm}×{region.depthKm} km</span>
              </div>
              <div className="panel-tight p-3 rounded-xl overflow-hidden relative">
                {velocityMap ? (
                  <VelocityMapCanvas
                    map={velocityMap}
                    reveal={mapProgress}
                    highlight={selected ?? primaryVein}
                    onSelect={setSelected}
                    height={340}
                  />
                ) : (
                  <EmptyMap />
                )}
                {velocityMap && (
                  <div className="absolute left-5 top-5 flex items-center gap-3 pointer-events-none">
                    <DepthAxisLabel depthKm={region.depthKm} />
                  </div>
                )}
                {velocityMap && (
                  <div className="absolute bottom-4 left-5 right-5 flex items-center justify-between pointer-events-none">
                    <span className="label-eyebrow">0 km</span>
                    <VelocityLegend />
                    <span className="label-eyebrow">{region.widthKm} km</span>
                  </div>
                )}
              </div>
              <div className="mt-3 text-xs text-slate-500 leading-relaxed">
                Colour scale: cool tones = slower sedimentary cover; warm tones = high-velocity
                anomalies. Red markers = candidate ore veins. Click any marker to inspect.
              </div>
            </div>
          </div>

          <div className="lg:col-span-4 space-y-6">
            <div className="panel p-5">
              <SectionLabel icon={<Crosshair className="w-4 h-4" />} title="5 · Vein candidate report" />
              <div className="mt-4">
                {velocityMap && velocityMap.candidates.length > 0 ? (
                  <div className="space-y-3">
                    {(selected ? [selected, ...velocityMap.candidates.filter((c) => c !== selected)] : velocityMap.candidates).map((c, i) => (
                      <CandidateCard key={`${c.row}-${c.col}`} c={c} active={selected === c || (i === 0 && !selected)} onClick={() => setSelected(c)} />
                    ))}
                  </div>
                ) : (
                  <div className="text-sm text-slate-500 py-8 text-center">
                    No candidates yet. Run a scan to surface anomalies.
                  </div>
                )}
              </div>
            </div>

            {state === 'complete' && primaryVein && (
              <div className="panel p-5 animate-fade-up">
                <SectionLabel icon={<Mountain className="w-4 h-4" />} title="Interpretation" />
                <div className="mt-4 space-y-3 text-sm leading-relaxed text-slate-300">
                  <p>
                    The strongest anomaly sits at <span className="text-aqua-300 stat-mono">{primaryVein.depthKm.toFixed(1)} km</span>{' '}
                    depth, offset <span className="text-aqua-300 stat-mono">{primaryVein.xKm.toFixed(1)} km</span>{' '}
                    along the profile. Its P-wave velocity of{' '}
                    <span className="text-aqua-300 stat-mono">{primaryVein.velocityKms.toFixed(2)} km/s</span>{' '}
                    is <span className="text-rust-400 stat-mono">+{primaryVein.contrast.toFixed(2)} km/s</span>{' '}
                    above the surrounding host rock.
                  </p>
                  <p>
                    Geophysical discriminants: Vp/Vs ={' '}
                    <span className="text-aqua-300 stat-mono">{primaryVein.vpVsRatio.toFixed(2)}</span>, acoustic impedance ={' '}
                    <span className="text-aqua-300 stat-mono">{primaryVein.impedance.toFixed(1)}</span>.
                    Elevated Vp/Vs and high impedance together are the seismic fingerprint of dense
                    sulphide / oxide mineralisation.
                  </p>
                  <p>
                    Lithology context: <span className="text-slate-200">{primaryVein.lithology}</span>.
                    A high-velocity tabular body inside a crystalline host is consistent with a
                    dense vein contact — flagged as a primary drilling target.
                  </p>
                  <div className="pt-2 flex items-center gap-2 text-xs text-slate-500">
                    <ArrowDownToLine className="w-3.5 h-3.5" />
                    Confidence is the CNN softmax output over background-vs-vein logits.
                  </div>
                </div>
              </div>
            )}

            {state === 'complete' && velocityMap && (
              <div className="panel p-5 animate-fade-up">
                <SectionLabel icon={<Cpu className="w-4 h-4" />} title="CNN training metrics" />
                <div className="mt-3">
                  <TrainingCurve history={velocityMap.trainHistory} />
                </div>
                <div className="mt-3 text-xs text-slate-500 leading-relaxed">
                  Loss = cross-entropy between softmax output and ground-truth vein labels
                  (from the embedded-vein mask). The network learns directly from the
                  reconstructed velocity map — same train-on-labelled-data strategy as the
                  cited CNN papers.
                </div>
              </div>
            )}
          </div>
        </section>

        {/* Method provenance */}
        <section className="panel p-6 animate-fade-up">
          <SectionLabel icon={<Database className="w-4 h-4" />} title="Method provenance — mapped to cited literature" />
          <div className="mt-4 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            <ProvenanceCard
              tag="Stage 1 · Acquisition"
              title="STEAD earthquake waveform dataset"
              refId="IEEE 8871127"
              body="~1.2M local earthquake + noise time series. We synthesise STEAD-style waveforms so the pipeline ingests a genuine seismic signal rather than an idealised sine."
            />
            <ProvenanceCard
              tag="Stage 2 · Preprocessing"
              title="Distributed Acoustic Sensing workflow"
              refId="IEEE 11223208"
              body="DAS processing pipeline: denoising, normalisation, event detection. We apply a 1.2–18 Hz bandpass + adaptive envelope as the DAS-style preprocessing analog."
            />
            <ProvenanceCard
              tag="Stage 3 · Reflection analysis"
              title="Seismic reflection event detection"
              refId="IEEE 9102272"
              body="Reflections occur at underground velocity boundaries. Our envelope picker isolates P, S, surface and reflection phases from the denoised trace."
            />
            <ProvenanceCard
              tag="Stage 4 · Reconstruction"
              title="Seismic velocity variation imaging"
              refId="IEEE 10974575"
              body="Reconstructing subsurface seismic-velocity variations reveals boundaries between geological materials. We invert travel-time picks into a 2-D Vp cross-section."
            />
            <ProvenanceCard
              tag="Stage 5 · Classification"
              title="CNN-based subsurface mapping"
              refId="IEEE 10921706"
              body="A CNN that converts geophysical measurements into an underground property map. Our Conv-Net (Conv→ReLU→MaxPool×2→Dense→Softmax) trains on labelled 9×9 velocity patches extracted from the reconstructed map, then classifies each cell as vein / background."
            />
            <ProvenanceCard
              tag="Stage 5 · Lithology"
              title="CNN lithological mapping"
              refId="IEEE 10457542"
              body="CNN mapping of geological rock types for prospecting. We assign a lithology label to each anomaly to check it sits in a mineralisation-favourable setting."
            />
          </div>
        </section>

        <footer className="pt-6 pb-12 text-center label-eyebrow">
          SeismoReveal · educational research build · techniques adapted from the cited IEEE literature
        </footer>
      </main>
    </div>
  );
}

// ---- helpers / small components ---------------------------------------------

function downsample(arr: number[], target: number): number[] {
  if (arr.length <= target) return arr;
  const step = arr.length / target;
  const out: number[] = [];
  for (let i = 0; i < target; i++) out.push(arr[Math.floor(i * step)]);
  return out;
}

function SectionLabel({ icon, title }: { icon: React.ReactNode; title: string }) {
  return (
    <div className="flex items-center gap-2 text-slate-300">
      <span className="text-aqua-400/80">{icon}</span>
      <span className="text-xs font-medium uppercase tracking-[0.18em]">{title}</span>
    </div>
  );
}

function Slider({
  label,
  value,
  min,
  max,
  step,
  unit,
  onChange,
  accent,
}: {
  label: string;
  value: number;
  min: number;
  max: number;
  step: number;
  unit: string;
  onChange: (v: number) => void;
  accent: 'aqua' | 'rust';
}) {
  const pct = ((value - min) / (max - min)) * 100;
  const color = accent === 'rust' ? 'rust-500' : 'aqua-500';
  return (
    <div>
      <div className="flex items-center justify-between mb-2">
        <span className="text-xs text-slate-400">{label}</span>
        <span className={`stat-mono text-sm ${accent === 'rust' ? 'text-rust-400' : 'text-aqua-300'}`}>
          {value.toFixed(step < 1 ? 1 : 0)} <span className="text-slate-500 text-xs">{unit}</span>
        </span>
      </div>
      <input
        type="range"
        min={min}
        max={max}
        step={step}
        value={value}
        onChange={(e) => onChange(parseFloat(e.target.value))}
        className="w-full h-1.5 rounded-full appearance-none cursor-pointer bg-white/10
          [&::-webkit-slider-thumb]:appearance-none [&::-webkit-slider-thumb]:w-4 [&::-webkit-slider-thumb]:h-4
          [&::-webkit-slider-thumb]:rounded-full [&::-webkit-slider-thumb]:bg-white [&::-webkit-slider-thumb]:shadow-[0_0_12px_rgba(45,212,191,0.5)]
          [&::-moz-range-thumb]:w-4 [&::-moz-range-thumb]:h-4 [&::-moz-range-thumb]:rounded-full [&::-moz-range-thumb]:border-0 [&::-moz-range-thumb]:bg-white"
        style={{
          background: `linear-gradient(90deg, var(--tw-${color}) 0%, var(--tw-${color}) ${pct}%, rgba(255,255,255,0.08) ${pct}%, rgba(255,255,255,0.08) 100%)`,
        }}
      />
    </div>
  );
}

function CandidateCard({ c, active, onClick }: { c: VeinCandidate; active: boolean; onClick: () => void }) {
  const color =
    c.status === 'primary'
      ? 'text-rust-400 border-rust-500/40 bg-rust-500/[0.07]'
      : c.status === 'secondary'
      ? 'text-ember-400 border-ember-500/30 bg-ember-500/[0.05]'
      : 'text-slate-400 border-white/5 bg-white/[0.02]';
  return (
    <button
      onClick={onClick}
      className={`w-full text-left px-4 py-3 rounded-xl border transition-all duration-300 ${color} ${
        active ? 'ring-1 ring-white/20' : ''
      }`}
    >
      <div className="flex items-center justify-between">
        <span className="text-xs font-medium uppercase tracking-wider">
          {c.status === 'primary' ? 'Primary target' : c.status === 'secondary' ? 'Secondary' : 'Low confidence'}
        </span>
        <span className="stat-mono text-sm">{(c.oreConfidence * 100).toFixed(0)}%</span>
      </div>
      <div className="mt-2 grid grid-cols-3 gap-2 text-xs">
        <Stat label="Depth" value={`${c.depthKm.toFixed(1)} km`} />
        <Stat label="Offset" value={`${c.xKm.toFixed(1)} km`} />
        <Stat label="Vp" value={`${c.velocityKms.toFixed(2)}`} />
        <Stat label="Vp/Vs" value={`${c.vpVsRatio.toFixed(2)}`} />
        <Stat label="Imp." value={`${c.impedance.toFixed(1)}`} />
        <Stat label="Contrast" value={`+${c.contrast.toFixed(2)}`} />
      </div>
      <div className="mt-2 text-[11px] text-slate-400">{c.lithology}</div>
    </button>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div>
      <div className="label-eyebrow">{label}</div>
      <div className="stat-mono text-slate-200">{value}</div>
    </div>
  );
}

function ProvenanceCard({ tag, title, refId, body }: { tag: string; title: string; refId: string; body: string }) {
  return (
    <div className="panel-tight p-4 hover:border-white/10 transition-colors duration-300">
      <div className="label-eyebrow text-aqua-400/80">{tag}</div>
      <div className="mt-1.5 text-sm font-medium text-white">{title}</div>
      <div className="mt-1 text-[11px] font-mono text-slate-500">{refId}</div>
      <p className="mt-2 text-xs text-slate-400 leading-relaxed">{body}</p>
    </div>
  );
}

function EmptyWaveform({ label }: { label?: string }) {
  return (
    <div className="h-[110px] flex items-center justify-center text-slate-600 text-xs label-eyebrow">
      {label ?? 'awaiting signal'}
    </div>
  );
}

function EmptyMap() {
  return (
    <div className="h-[340px] flex items-center justify-center grid-backdrop rounded-xl">
      <div className="text-center">
        <Layers className="w-6 h-6 text-slate-700 mx-auto mb-2" />
        <div className="label-eyebrow text-slate-600">velocity map renders after reconstruction</div>
      </div>
    </div>
  );
}

function DepthAxisLabel({ depthKm }: { depthKm: number }) {
  return (
    <div className="flex flex-col items-start gap-0">
      <span className="label-eyebrow text-slate-600">surface</span>
      <div className="w-px h-[260px] bg-gradient-to-b from-white/10 to-transparent" />
      <span className="label-eyebrow text-slate-600 mt-1">{depthKm} km depth</span>
    </div>
  );
}

function VelocityLegend() {
  return (
    <div className="flex items-center gap-2">
      <div
        className="w-32 h-2 rounded-full"
        style={{
          background: 'linear-gradient(90deg, rgb(10,18,40), rgb(18,60,78), rgb(20,130,120), rgb(240,180,60), rgb(244,63,94))',
        }}
      />
      <span className="label-eyebrow">Vp</span>
    </div>
  );
}

function ReferenceBadges() {
  return (
    <div className="flex flex-col gap-1.5 items-end">
      {['IEEE 10974575', 'IEEE 9102272', 'IEEE 11223208', 'IEEE 8871127', 'IEEE 10921706', 'IEEE 10457542'].map((r) => (
        <span key={r} className="label-eyebrow text-slate-600">{r}</span>
      ))}
    </div>
  );
}

function BackdropParticles() {
  // Subtle animated backdrop — seismic-wave concentric rings drifting outward.
  const rings = useMemo(() => Array.from({ length: 4 }, (_, i) => i), []);
  return (
    <div className="fixed inset-0 pointer-events-none overflow-hidden opacity-40">
      <div className="absolute -top-1/3 left-1/2 -translate-x-1/2 w-[1200px] h-[1200px]">
        {rings.map((i) => (
          <div
            key={i}
            className="absolute inset-0 rounded-full border border-aqua-500/10 animate-pulse-ring"
            style={{ animationDelay: `${i * 0.7}s`, transform: 'scale(0.4)' }}
          />
        ))}
      </div>
    </div>
  );
}
