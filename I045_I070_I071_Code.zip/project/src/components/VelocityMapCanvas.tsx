import { useEffect, useRef } from 'react';
import { velocityColor, type VelocityMap, type VeinCandidate } from '@/engine/tomography';
import { rgb } from '@/components/presets';

type Props = {
  map: VelocityMap;
  reveal: number; // 0..1 — how much of the velocity map has been "reconstructed"
  highlight?: VeinCandidate | null;
  onSelect?: (c: VeinCandidate) => void;
  height?: number;
};

// Renders the 2-D seismic-velocity cross-section and overlays ore-vein candidates.
export default function VelocityMapCanvas({ map, reveal, highlight, onSelect, height = 320 }: Props) {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    const dpr = window.devicePixelRatio || 1;

    const render = () => {
      const rect = canvas.getBoundingClientRect();
      const w = Math.floor(rect.width * dpr);
      const h = Math.floor(height * dpr);
      if (canvas.width !== w || canvas.height !== h) canvas.width = w;
      if (canvas.height !== h) canvas.height = h;
      ctx.setTransform(1, 0, 0, 1, 0, 0);
      ctx.clearRect(0, 0, w, h);

      const { grid, region, candidates } = map;
      const { rows, cols } = region;
      const cellW = w / cols;
      const cellH = h / rows;

      // Velocity range for colour normalisation.
      let minVp = Infinity;
      let maxVp = -Infinity;
      for (let i = 0; i < grid.length; i++) {
        if (grid[i] < minVp) minVp = grid[i];
        if (grid[i] > maxVp) maxVp = grid[i];
      }

      // Reveal progressive columns left-to-right (tomographic sweep).
      const visibleCols = Math.max(1, Math.floor(cols * reveal));

      // Cell fill — draw with bilinear-smoothed colouring by averaging a 2x2 block.
      for (let r = 0; r < rows; r++) {
        for (let c = 0; c < visibleCols; c++) {
          const v = grid[r * cols + c];
          const [cr, cg, cb] = velocityColor(v, minVp, maxVp);
          ctx.fillStyle = rgb(cr, cg, cb);
          ctx.fillRect(c * cellW, r * cellH, Math.ceil(cellW) + 1, Math.ceil(cellH) + 1);
        }
      }

      // Unrevealed zone — subtle grid hint.
      ctx.fillStyle = 'rgba(5,7,11,0.55)';
      ctx.fillRect(visibleCols * cellW, 0, w - visibleCols * cellW, h);
      ctx.strokeStyle = 'rgba(148,163,184,0.04)';
      ctx.lineWidth = 1;
      for (let c = visibleCols; c <= cols; c += 2) {
        const x = c * cellW;
        ctx.beginPath();
        ctx.moveTo(x, 0);
        ctx.lineTo(x, h);
        ctx.stroke();
      }

      // Scan line.
      if (reveal < 1) {
        const sx = visibleCols * cellW;
        ctx.strokeStyle = 'rgba(94,234,212,0.7)';
        ctx.lineWidth = 1.5 * dpr;
        ctx.beginPath();
        ctx.moveTo(sx, 0);
        ctx.lineTo(sx, h);
        ctx.stroke();
        const halo = ctx.createLinearGradient(sx - 60 * dpr, 0, sx + 6 * dpr, 0);
        halo.addColorStop(0, 'rgba(94,234,212,0)');
        halo.addColorStop(1, 'rgba(94,234,212,0.16)');
        ctx.fillStyle = halo;
        ctx.fillRect(sx - 60 * dpr, 0, 66 * dpr, h);
      }

      // Candidate markers (only in revealed region).
      candidates.forEach((cand) => {
        if (cand.col >= visibleCols) return;
        const cx = (cand.col + 0.5) * cellW;
        const cy = (cand.row + 0.5) * cellH;
        const isPrimary = cand.status === 'primary';
        const isSecondary = cand.status === 'secondary';
        const isHighlight = highlight?.row === cand.row && highlight?.col === cand.col;

        const baseColor =
          cand.status === 'low'
            ? 'rgba(148,163,184,0.5)'
            : cand.status === 'secondary'
            ? 'rgba(251,191,36,0.95)'
            : 'rgba(244,63,94,0.95)';
        const radius = (isPrimary ? 9 : isSecondary ? 7 : 5) * dpr;

        // Pulsing ring on the primary vein.
        if (isPrimary) {
          const t = (Date.now() % 2800) / 2800;
          const ringR = radius + t * 24 * dpr;
          ctx.strokeStyle = `rgba(244,63,94,${0.5 * (1 - t)})`;
          ctx.lineWidth = 1.5 * dpr;
          ctx.beginPath();
          ctx.arc(cx, cy, ringR, 0, Math.PI * 2);
          ctx.stroke();
        }

        // Crosshair.
        ctx.strokeStyle = baseColor;
        ctx.lineWidth = (isHighlight ? 2 : 1.2) * dpr;
        const arm = radius + 4 * dpr;
        ctx.beginPath();
        ctx.moveTo(cx - arm, cy);
        ctx.lineTo(cx + arm, cy);
        ctx.moveTo(cx, cy - arm);
        ctx.lineTo(cx, cy + arm);
        ctx.stroke();

        // Dot.
        ctx.fillStyle = baseColor;
        ctx.beginPath();
        ctx.arc(cx, cy, isHighlight ? radius * 1.4 : radius, 0, Math.PI * 2);
        ctx.fill();

        if (isHighlight || isPrimary) {
          ctx.fillStyle = 'rgba(5,7,11,0.9)';
          ctx.font = `${10 * dpr}px JetBrains Mono, monospace`;
          ctx.fillText(`Vp ${cand.velocityKms.toFixed(2)}`, cx + arm + 2, cy - 4 * dpr);
          ctx.fillText(`conf ${(cand.oreConfidence * 100).toFixed(0)}%`, cx + arm + 2, cy + 10 * dpr);
        }
      });
    };

    let raf: number;
    const loop = () => {
      render();
      raf = requestAnimationFrame(loop);
    };
    loop();
    return () => cancelAnimationFrame(raf);
  }, [map, reveal, highlight, height]);

  // Click -> nearest candidate.
  const handleClick = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (!onSelect) return;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    const { region, candidates } = map;
    const cellW = rect.width / region.cols;
    const cellH = rect.height / region.rows;
    let best: VeinCandidate | null = null;
    let bestDist = Infinity;
    for (const c of candidates) {
      const cx = (c.col + 0.5) * cellW;
      const cy = (c.row + 0.5) * cellH;
      const d = (cx - x) ** 2 + (cy - y) ** 2;
      if (d < bestDist) {
        bestDist = d;
        best = c;
      }
    }
    if (best) onSelect(best);
  };

  return (
    <canvas
      ref={canvasRef}
      style={{ width: '100%', height }}
      className="block cursor-crosshair"
      onClick={handleClick}
    />
  );
}
