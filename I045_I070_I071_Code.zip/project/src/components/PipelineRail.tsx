import { Check, Loader2 } from 'lucide-react';

export type StageState = 'pending' | 'active' | 'done';

type Props = {
  stages: { id: string; label: string; sub: string; state: StageState }[];
};

// Vertical pipeline status rail — shows each processing step animating through.
export default function PipelineRail({ stages }: Props) {
  return (
    <div className="flex flex-col gap-1">
      {stages.map((s, i) => (
        <div
          key={s.id}
          className={`flex items-start gap-3 px-3 py-3 rounded-xl transition-all duration-700 ${
            s.state === 'active'
              ? 'bg-aqua-500/10 border border-aqua-500/30'
              : s.state === 'done'
              ? 'bg-white/[0.02] border border-white/5'
              : 'border border-transparent opacity-50'
          }`}
          style={{ animationDelay: `${i * 80}ms` }}
        >
          <div className="mt-0.5">
            {s.state === 'done' ? (
              <div className="w-5 h-5 rounded-full bg-aqua-500/20 flex items-center justify-center">
                <Check className="w-3 h-3 text-aqua-400" />
              </div>
            ) : s.state === 'active' ? (
              <Loader2 className="w-5 h-5 text-aqua-400 animate-spin" />
            ) : (
              <div className="w-5 h-5 rounded-full border border-white/10" />
            )}
          </div>
          <div className="flex-1 min-w-0">
            <div
              className={`text-sm font-medium ${
                s.state === 'active' ? 'text-white' : s.state === 'done' ? 'text-slate-300' : 'text-slate-500'
              }`}
            >
              {s.label}
            </div>
            <div className="text-xs text-slate-500 mt-0.5 leading-relaxed">{s.sub}</div>
          </div>
          <div className="label-eyebrow mt-1">{String(i + 1).padStart(2, '0')}</div>
        </div>
      ))}
    </div>
  );
}
