// Shared small canvas helpers + region presets.

export type RegionPreset = {
  id: string;
  name: string;
  widthKm: number;
  depthKm: number;
  baseRock: 'sediment' | 'basalt' | 'granite';
  description: string;
};

export const REGION_PRESETS: RegionPreset[] = [
  {
    id: 'cuyama',
    name: 'Cuyama Basin',
    widthKm: 24,
    depthKm: 12,
    baseRock: 'sediment',
    description: 'Sedimentary fill overlying basement — classic reflection-survey geometry.',
  },
  {
    id: 'olympic',
    name: 'Olympic Forearc',
    widthKm: 32,
    depthKm: 16,
    baseRock: 'basalt',
    description: 'Accreted basaltic terrane — strong velocity contrast at vein contacts.',
  },
  {
    id: 'wheatstone',
    name: 'Wheatstone Craton',
    widthKm: 28,
    depthKm: 14,
    baseRock: 'granite',
    description: 'Granitic craton — crystalline host for disseminated sulphide veins.',
  },
];

// Map a value into a hex colour string.
export function rgb(r: number, g: number, b: number): string {
  return `rgb(${r},${g},${b})`;
}

// Easing for the staged processing reveal.
export function easeOutCubic(t: number): number {
  return 1 - Math.pow(1 - t, 3);
}
