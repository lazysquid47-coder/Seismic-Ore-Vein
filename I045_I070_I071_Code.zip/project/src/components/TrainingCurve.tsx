import { useMemo } from 'react';
import type { TrainHistory } from '@/engine/cnn';

type Props = {
  history: TrainHistory[];
  height?: number;
};

// Plots the CNN training loss + accuracy curve on a shared canvas.
export default function TrainingCurve({ history, height = 120 }: Props) {
  const loss = useMemo(() => history.map((h) => h.loss), [history]);
  const acc = useMemo(() => history.map((h) => h.acc), [history]);
  const n = loss.length;
  const maxLoss = useMemo(() => Math.max(0.1, ...loss), [loss]);
  const points = useMemo(() => {
    const lossPts: string[] = [];
    const accPts: string[] = [];
    for (let i = 0; i < n; i++) {
      const x = n <= 1 ? 0 : (i / (n - 1)) * 100;
      const yL = 100 - (loss[i] / maxLoss) * 100;
      const yA = 100 - acc[i] * 100;
      lossPts.push(`${x.toFixed(1)},${yL.toFixed(1)}`);
      accPts.push(`${x.toFixed(1)},${yA.toFixed(1)}`);
    }
    return { lossPts: lossPts.join(' '), accPts: accPts.join(' ') };
  }, [loss, acc, n, maxLoss]);

  if (n === 0) {
    return (
      <div className="h-[120px] flex items-center justify-center text-slate-600 text-xs label-eyebrow">
        training curve appears after CNN trains
      </div>
    );
  }

  return (
    <div className="relative">
      <svg viewBox="0 0 100 100" preserveAspectRatio="none" style={{ width: '100%', height }} className="overflow-visible">
        {/* grid */}
        {[0, 25, 50, 75, 100].map((y) => (
          <line key={y} x1="0" y1={y} x2="100" y2={y} stroke="rgba(148,163,184,0.06)" strokeWidth="0.4" />
        ))}
        {/* loss curve */}
        <polyline points={points.lossPts} fill="none" stroke="rgba(244,63,94,0.9)" strokeWidth="1.2" vectorEffect="non-scaling-stroke" />
        {/* accuracy curve */}
        <polyline points={points.accPts} fill="none" stroke="rgba(94,234,212,0.9)" strokeWidth="1.2" vectorEffect="non-scaling-stroke" />
      </svg>
      <div className="flex items-center gap-4 mt-2 text-[10px] font-mono">
        <span className="flex items-center gap-1.5 text-rust-400">
          <span className="w-3 h-0.5 bg-rust-500" /> loss {(loss[n - 1] ?? 0).toFixed(3)}
        </span>
        <span className="flex items-center gap-1.5 text-aqua-400">
          <span className="w-3 h-0.5 bg-aqua-500" /> acc {((acc[n - 1] ?? 0) * 100).toFixed(0)}%
        </span>
        <span className="text-slate-500 ml-auto">{n} epochs</span>
      </div>
    </div>
  );
}
