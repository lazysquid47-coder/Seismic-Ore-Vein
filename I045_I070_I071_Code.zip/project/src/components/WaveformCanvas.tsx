import { useEffect, useRef } from 'react';
import type { Arrival } from '@/engine/processing';

type Props = {
  data: number[];
  sampleRate: number;
  durationS: number;
  arrivals: Arrival[];
  variant: 'raw' | 'denoised' | 'envelope';
  progress: number; // 0..1 — how much of the trace has been "scanned"
  height?: number;
};

// Renders a single seismic trace to canvas with a slow scanning sweep.
export default function WaveformCanvas({ data, sampleRate, durationS, arrivals, variant, progress, height = 120 }: Props) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const frameRef = useRef<number | null>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const dpr = window.devicePixelRatio || 1;
    const render = () => {
      const rect = canvas.getBoundingClientRect();
      const w = Math.floor(rect.width * dpr);
      const h = Math.floor(height * dpr);
      if (canvas.width !== w || canvas.height !== h) {
        canvas.width = w;
        canvas.height = h;
      }
      ctx.setTransform(1, 0, 0, 1, 0, 0);
      ctx.clearRect(0, 0, w, h);

      // Background grid.
      ctx.strokeStyle = 'rgba(148,163,184,0.06)';
      ctx.lineWidth = 1;
      for (let i = 0; i <= 8; i++) {
        const x = (i / 8) * w;
        ctx.beginPath();
        ctx.moveTo(x, 0);
        ctx.lineTo(x, h);
        ctx.stroke();
      }
      for (let i = 0; i <= 3; i++) {
        const y = (i / 3) * h;
        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(w, y);
        ctx.stroke();
      }

      if (data.length < 2) return;

      // Auto-scale from the whole trace (not just the visible portion) so the
      // reveal doesn't cause rescaling jumps.
      let maxAbs = 1e-6;
      for (let i = 0; i < data.length; i++) {
        const a = Math.abs(data[i]);
        if (a > maxAbs) maxAbs = a;
      }
      const mid = h / 2;
      const amp = (h * 0.42) / maxAbs;

      // Revealed portion.
      const visibleCount = Math.max(2, Math.floor(data.length * progress));

      // Filled envelope or line trace.
      if (variant === 'envelope') {
        // Two-sided fill.
        ctx.beginPath();
        ctx.moveTo(0, mid);
        for (let i = 0; i < visibleCount; i++) {
          const x = (i / (data.length - 1)) * w;
          const y = mid - data[i] * amp;
          ctx.lineTo(x, y);
        }
        ctx.lineTo((visibleCount / data.length) * w, mid);
        ctx.closePath();
        const grad = ctx.createLinearGradient(0, 0, 0, h);
        grad.addColorStop(0, 'rgba(45,212,191,0.35)');
        grad.addColorStop(1, 'rgba(45,212,191,0.02)');
        ctx.fillStyle = grad;
        ctx.fill();
      }

      // Line trace.
      ctx.beginPath();
      ctx.strokeStyle =
        variant === 'raw'
          ? 'rgba(148,163,184,0.85)'
          : variant === 'denoised'
          ? 'rgba(94,234,212,0.95)'
          : 'rgba(45,212,191,0.9)';
      ctx.lineWidth = 1.4 * dpr;
      for (let i = 0; i < visibleCount; i++) {
        const x = (i / (data.length - 1)) * w;
        const y = mid - data[i] * amp;
        if (i === 0) ctx.moveTo(x, y);
        else ctx.lineTo(x, y);
      }
      ctx.stroke();

      // Unrevealed tail — faint ghost so the full shape is hinted at.
      ctx.beginPath();
      ctx.strokeStyle = 'rgba(148,163,184,0.12)';
      ctx.lineWidth = 1 * dpr;
      for (let i = visibleCount; i < data.length; i++) {
        const x = (i / (data.length - 1)) * w;
        const y = mid - data[i] * amp;
        if (i === visibleCount) ctx.moveTo(x, y);
        else ctx.lineTo(x, y);
      }
      ctx.stroke();

      // Arrival picks.
      arrivals.forEach((a) => {
        if (a.time / durationS > progress) return;
        const x = (a.time / durationS) * w;
        const color =
          a.phase === 'P'
            ? 'rgba(94,234,212,0.9)'
            : a.phase === 'S'
            ? 'rgba(251,191,36,0.9)'
            : a.phase === 'reflection'
            ? 'rgba(244,63,94,0.9)'
            : 'rgba(148,163,184,0.7)';
        ctx.strokeStyle = color;
        ctx.setLineDash([4 * dpr, 4 * dpr]);
        ctx.lineWidth = 1 * dpr;
        ctx.beginPath();
        ctx.moveTo(x, 0);
        ctx.lineTo(x, h);
        ctx.stroke();
        ctx.setLineDash([]);

        // Label.
        ctx.fillStyle = color;
        ctx.font = `${10 * dpr}px JetBrains Mono, monospace`;
        ctx.fillText(a.phase === 'reflection' ? 'REFL' : a.phase, x + 4 * dpr, 12 * dpr);
      });

      // Scanning sweep cursor.
      if (progress < 1) {
        const sx = progress * w;
        ctx.strokeStyle = 'rgba(94,234,212,0.55)';
        ctx.lineWidth = 1.5 * dpr;
        ctx.beginPath();
        ctx.moveTo(sx, 0);
        ctx.lineTo(sx, h);
        ctx.stroke();
        // Glow halo.
        const halo = ctx.createLinearGradient(sx - 40 * dpr, 0, sx + 4 * dpr, 0);
        halo.addColorStop(0, 'rgba(94,234,212,0)');
        halo.addColorStop(1, 'rgba(94,234,212,0.18)');
        ctx.fillStyle = halo;
        ctx.fillRect(sx - 40 * dpr, 0, 44 * dpr, h);
      }
    };

    render();
    const onResize = () => render();
    window.addEventListener('resize', onResize);
    return () => {
      window.removeEventListener('resize', onResize);
      if (frameRef.current) cancelAnimationFrame(frameRef.current);
    };
  }, [data, arrivals, progress, variant, height, durationS, sampleRate]);

  return <canvas ref={canvasRef} style={{ width: '100%', height }} className="block" />;
}
