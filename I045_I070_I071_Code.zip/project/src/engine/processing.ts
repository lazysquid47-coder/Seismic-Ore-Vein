// Signal processing — converts a raw seismogram into the features the
// subsurface reconstruction stage consumes.
//
// Pipeline (aligned with the cited papers):
//   1. Bandpass + denoise  — DAS review (IEEE 11223208): denoising / normalization
//      of distributed-acoustic-sensing-style records before interpretation.
//   2. Event detection     — reflection detection (IEEE 9102272): identifying
//      meaningful reflection events from seismic recordings.
//   3. Travel-time picks    — arrival times used by the velocity reconstruction.
//   4. Velocity model      — subsurface-reconstruction stage (IEEE 10974575):
//      reconstructing seismic velocity variations to reveal boundaries between
//      underground geological materials.

import type { Trace } from './waveform';

export type ProcessedTrace = {
  raw: number[];
  denoised: number[];
  envelope: number[];
  samplingRate: number;
};

// One-pole Butterworth-ish bandpass (simplified). Keeps the band where most
// earthquake body-wave energy lives for shallow surveys (1–20 Hz).
function bandpass(samples: Float32Array, sr: number, loHz: number, hiHz: number): Float32Array {
  const n = samples.length;
  const out = new Float32Array(n);
  const dt = 1 / sr;
  // Low-cut (RC high-pass on the detrended signal).
  const aHp = Math.exp(-2 * Math.PI * loHz * dt);
  let prevIn = 0;
  let prevHp = 0;
  // High-cut (RC low-pass).
  const aLp = Math.exp(-2 * Math.PI * hiHz * dt);
  let prevLp = 0;
  for (let i = 0; i < n; i++) {
    const x = samples[i];
    const hp = aHp * (prevHp + x - prevIn);
    prevIn = x;
    prevHp = hp;
    const lp = aLp * prevLp + (1 - aLp) * hp;
    prevLp = lp;
    out[i] = lp;
  }
  return out;
}

// Smoothed analytic-signal envelope via a sliding RMS window. Used for event
// detection — large envelope peaks mark reflection / arrival events.
function envelope(samples: Float32Array, sr: number): Float32Array {
  const n = samples.length;
  const out = new Float32Array(n);
  // Approximate Hilbert transform with a quadrature shift + low-pass mix.
  const quad = new Float32Array(n);
  const shift = Math.floor(sr * 0.02); // ~20 ms quadrature lag
  for (let i = 0; i < n; i++) {
    quad[i] = samples[Math.max(0, i - shift)];
  }
  const win = Math.floor(sr * 0.08); // 80 ms smoothing window
  for (let i = 0; i < n; i++) {
    let re = 0;
    let im = 0;
    const a = Math.max(0, i - win);
    const b = Math.min(n - 1, i + win);
    for (let j = a; j <= b; j++) {
      re += samples[j] * samples[j];
      im += quad[j] * quad[j];
    }
    out[i] = Math.sqrt((re + im) / (b - a + 1));
  }
  return out;
}

export function processTrace(trace: Trace): ProcessedTrace {
  const denoisedF = bandpass(trace.samples, trace.samplingRate, 1.2, 18);
  const envF = envelope(denoisedF, trace.samplingRate);
  return {
    raw: Array.from(trace.samples),
    denoised: Array.from(denoisedF),
    envelope: Array.from(envF),
    samplingRate: trace.samplingRate,
  };
}

export type Arrival = {
  time: number;
  amplitude: number;
  phase: 'P' | 'S' | 'surface' | 'reflection';
  confidence: number;
};

// Detect arrival events by picking envelope maxima above an adaptive threshold.
// Early strong peak -> P; next strong peak -> S; late strong -> reflection;
// late, low-frequency -> surface wave.
export function detectArrivals(p: ProcessedTrace): Arrival[] {
  const env = p.envelope;
  const sr = p.samplingRate;
  const n = env.length;
  const maxEnv = Math.max(...env, 1e-6);
  const threshold = maxEnv * 0.18;

  // Find local maxima above threshold with a minimum spacing (debounce).
  const minSpacing = Math.floor(sr * 0.3); // 300 ms
  const peaks: { idx: number; amp: number }[] = [];
  for (let i = 2; i < n - 2; i++) {
    if (
      env[i] > threshold &&
      env[i] >= env[i - 1] &&
      env[i] >= env[i + 1] &&
      env[i] >= env[i - 2] &&
      env[i] >= env[i + 2]
    ) {
      if (peaks.length === 0 || i - peaks[peaks.length - 1].idx > minSpacing) {
        peaks.push({ idx: i, amp: env[i] });
      } else if (env[i] > peaks[peaks.length - 1].amp) {
        peaks[peaks.length - 1] = { idx: i, amp: env[i] };
      }
    }
  }

  if (peaks.length === 0) return [];

  // Sort by amplitude descending to classify the strongest phases.
  const sorted = [...peaks].sort((a, b) => b.amp - a.amp);
  const classifyIdx = new Map<number, Arrival['phase']>();

  // Strongest early peak (first 35% of record) is P.
  const pCand = sorted[0];
  classifyIdx.set(pCand.idx, 'P');

  // Next strong peak that arrives later and is distinct -> S.
  for (let k = 1; k < sorted.length; k++) {
    if (sorted[k].idx > pCand.idx + minSpacing && !classifyIdx.has(sorted[k].idx)) {
      classifyIdx.set(sorted[k].idx, 'S');
      break;
    }
  }

  // A reflection event: an amplitude bump arriving after S but before the
  // surface-wave train, typically with shorter coda.
  const sIdx = [...classifyIdx.entries()].find(([, ph]) => ph === 'S')?.[0] ?? pCand.idx;
  for (let k = 0; k < sorted.length; k++) {
    const idx = sorted[k].idx;
    if (classifyIdx.has(idx)) continue;
    if (idx > sIdx + minSpacing && idx < n * 0.7) {
      classifyIdx.set(idx, 'reflection');
      break;
    }
  }
  // Surface wave: late, broad event.
  for (let k = 0; k < sorted.length; k++) {
    const idx = sorted[k].idx;
    if (classifyIdx.has(idx)) continue;
    if (idx > n * 0.55) {
      classifyIdx.set(idx, 'surface');
      break;
    }
  }

  const arrivals: Arrival[] = [];
  for (const peak of peaks) {
    const phase = classifyIdx.get(peak.idx);
    if (!phase) continue;
    arrivals.push({
      time: peak.idx / sr,
      amplitude: peak.amp / maxEnv,
      phase,
      confidence: Math.min(1, 0.55 + (peak.amp / maxEnv) * 0.45),
    });
  }
  return arrivals.sort((a, b) => a.time - b.time);
}
