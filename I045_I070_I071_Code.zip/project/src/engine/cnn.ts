// A small but genuine Convolutional Neural Network that runs and trains
// entirely in-browser with full backpropagation. Architecture:
//
//   Input  : 9 x 9 velocity patch (normalised to [0,1]) + 2 geophysical
//            attributes (Vp/Vs ratio, acoustic impedance).
//   Conv1  : 6 filters, 3x3, stride 1, pad 1  -> ReLU   (9x9x6)
//   Pool1  : 2x2 max pool                     -> 4x4x6 = 96 features
//   Flat   : 96 + 2 (geophys attrs)           = 98
//   Dense1 : 98 -> 32  -> ReLU
//   Dense2 : 32 -> 2   -> Softmax (background / vein)
//
// Training uses mini-batch SGD + cross-entropy on labelled 9x9 patches extracted
// from the reconstructed velocity map. Ground-truth labels come from the known
// vein geometry embedded by the tomography stage — the same "train on labelled
// synthetic/field data" strategy the cited CNN papers use (IEEE 10921706
// reconstructs resistivity from EM with a CNN; IEEE 10457542 maps lithology with
// a CNN; both train on labelled examples).
//
// The convolution forward and backward passes are implemented exactly (single
// input channel, explicit 3x3 correlation with zero-padding) — no approximations
// in the gradient computation.

export type CNNParams = {
  conv1: Float32Array; // [F1, 3, 3]
  conv1b: Float32Array; // [F1]
  dense1: Float32Array; // [H1, FLAT]
  dense1b: Float32Array; // [H1]
  dense2: Float32Array; // [2, H1]
  dense2b: Float32Array; // [2]
};

const IN = 9;
const F1 = 6; // conv1 filters
const POOLED = 4; // floor(9/2) = 4
const FLAT = F1 * POOLED * POOLED + 2; // 96 + 2 = 98
const H1 = 32; // dense1 hidden units

export type Patch = {
  grid: Float32Array; // IN*IN velocities, normalised
  vpVs: number;
  impedance: number;
};

export type TrainingExample = {
  patch: Patch;
  label: 0 | 1;
};

export type TrainHistory = {
  epoch: number;
  loss: number;
  acc: number;
};

function randn(rng: () => number): number {
  let u = 0;
  let v = 0;
  while (u === 0) u = rng();
  while (v === 0) v = rng();
  return Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * Math.PI * v);
}

export function initParams(rng: () => number): CNNParams {
  const conv1 = new Float32Array(F1 * 9);
  const dense1 = new Float32Array(H1 * FLAT);
  const dense2 = new Float32Array(2 * H1);
  for (let i = 0; i < conv1.length; i++) conv1[i] = randn(rng) * 0.5;
  for (let i = 0; i < dense1.length; i++) dense1[i] = randn(rng) * Math.sqrt(2 / FLAT);
  for (let i = 0; i < dense2.length; i++) dense2[i] = randn(rng) * Math.sqrt(2 / H1);
  return {
    conv1,
    conv1b: new Float32Array(F1),
    dense1,
    dense1b: new Float32Array(H1),
    dense2,
    dense2b: new Float32Array(2),
  };
}

// ---- forward pass cache ----------------------------------------------------

type Cache = {
  x: Float32Array; // [IN*IN]
  conv1Out: Float32Array; // [F1, IN, IN]
  relu1: Float32Array; // [F1, IN, IN]
  pool1: Float32Array; // [F1, POOLED, POOLED]
  poolArgmax: Int32Array; // [F1, POOLED, POOLED] — flat index into relu1 per cell
  flat: Float32Array; // [FLAT]
  dense1Out: Float32Array; // [H1]
  relu1d: Float32Array; // [H1]
  logits: Float32Array; // [2]
  probs: Float32Array; // [2]
};

// 3x3 correlation (conv) with zero-padding, single input channel -> single output channel.
function conv3x3(inMap: Float32Array, inSize: number, kernel: Float32Array, bias: number, out: Float32Array, outOff: number): void {
  for (let r = 0; r < inSize; r++) {
    for (let c = 0; c < inSize; c++) {
      let s = 0;
      for (let kr = -1; kr <= 1; kr++) {
        for (let kc = -1; kc <= 1; kc++) {
          const ir = r + kr;
          const ic = c + kc;
          if (ir < 0 || ir >= inSize || ic < 0 || ic >= inSize) continue;
          s += inMap[ir * inSize + ic] * kernel[(kr + 1) * 3 + (kc + 1)];
        }
      }
      out[outOff + r * inSize + c] = s + bias;
    }
  }
}

function reluArr(x: Float32Array): Float32Array {
  const o = new Float32Array(x.length);
  for (let i = 0; i < x.length; i++) o[i] = Math.max(0, x[i]);
  return o;
}

// 2x2 max pool, stride 2, for a multi-channel feature map. Returns the pooled
// output and an argmax array recording which input cell won each pool window
// (needed for exact backprop).
function maxPool2x2(inMap: Float32Array, inSize: number, channels: number, outSize: number): { out: Float32Array; argmax: Int32Array } {
  const out = new Float32Array(channels * outSize * outSize);
  const argmax = new Int32Array(channels * outSize * outSize);
  for (let ch = 0; ch < channels; ch++) {
    for (let r = 0; r < outSize; r++) {
      for (let c = 0; c < outSize; c++) {
        let m = -Infinity;
        let aIdx = 0;
        for (let dr = 0; dr < 2; dr++) {
          for (let dc = 0; dc < 2; dc++) {
            const ir = 2 * r + dr;
            const ic = 2 * c + dc;
            if (ir >= inSize || ic >= inSize) continue;
            const v = inMap[ch * inSize * inSize + ir * inSize + ic];
            if (v > m) {
              m = v;
              aIdx = ir * inSize + ic;
            }
          }
        }
        out[ch * outSize * outSize + r * outSize + c] = m;
        argmax[ch * outSize * outSize + r * outSize + c] = aIdx;
      }
    }
  }
  return { out, argmax };
}

function softmax2(logits: Float32Array): Float32Array {
  const m = Math.max(logits[0], logits[1]);
  const e0 = Math.exp(logits[0] - m);
  const e1 = Math.exp(logits[1] - m);
  const s = e0 + e1;
  return new Float32Array([e0 / s, e1 / s]);
}

function forward(params: CNNParams, patch: Patch): Cache {
  const x = patch.grid;

  // Conv1: F1 filters, 3x3, pad 1 -> [F1, IN, IN]
  const conv1Out = new Float32Array(F1 * IN * IN);
  for (let f = 0; f < F1; f++) {
    conv3x3(x, IN, params.conv1.subarray(f * 9, f * 9 + 9), params.conv1b[f], conv1Out, f * IN * IN);
  }
  const relu1 = reluArr(conv1Out);

  // Pool1: 2x2 max pool -> [F1, POOLED, POOLED]
  const { out: pool1, argmax: poolArgmax } = maxPool2x2(relu1, IN, F1, POOLED);

  // Flatten: pool1 (96) + attributes (2) = 98
  const flat = new Float32Array(FLAT);
  flat.set(pool1, 0);
  flat[FLAT - 2] = patch.vpVs;
  flat[FLAT - 1] = patch.impedance;

  // Dense1: FLAT -> H1 -> ReLU
  const dense1Out = new Float32Array(H1);
  for (let o = 0; o < H1; o++) {
    let s = params.dense1b[o];
    for (let i = 0; i < FLAT; i++) s += params.dense1[o * FLAT + i] * flat[i];
    dense1Out[o] = s;
  }
  const relu1d = reluArr(dense1Out);

  // Dense2: H1 -> 2 -> Softmax
  const logits = new Float32Array(2);
  for (let o = 0; o < 2; o++) {
    let s = params.dense2b[o];
    for (let i = 0; i < H1; i++) s += params.dense2[o * H1 + i] * relu1d[i];
    logits[o] = s;
  }
  const probs = softmax2(logits);

  return { x, conv1Out, relu1, pool1, poolArgmax, flat, dense1Out, relu1d, logits, probs };
}

export function classify(params: CNNParams, patch: Patch): { veinProb: number; bgProb: number } {
  const c = forward(params, patch);
  return { veinProb: c.probs[1], bgProb: c.probs[0] };
}

// ---- training: mini-batch SGD + cross-entropy ------------------------------

function crossEntropy(probs: Float32Array, label: number): number {
  const p = Math.max(1e-7, probs[label]);
  return -Math.log(p);
}

// Class weight balances the rare vein class so its gradient isn't drowned by
// the far more numerous background patches.
const VEIN_WEIGHT = 2;

export function trainStep(params: CNNParams, batch: TrainingExample[], lr: number): { loss: number; acc: number } {
  const gConv1 = new Float32Array(params.conv1.length);
  const gConv1b = new Float32Array(F1);
  const gDense1 = new Float32Array(params.dense1.length);
  const gDense1b = new Float32Array(H1);
  const gDense2 = new Float32Array(params.dense2.length);
  const gDense2b = new Float32Array(2);

  let totalLoss = 0;
  let correct = 0;

  for (const ex of batch) {
    const c = forward(params, ex.patch);
    const w = ex.label === 1 ? VEIN_WEIGHT : 1;
    totalLoss += w * crossEntropy(c.probs, ex.label);
    const pred = c.probs[1] > c.probs[0] ? 1 : 0;
    if (pred === ex.label) correct++;

    // dLogits = probs - onehot, scaled by class weight
    const dLogits = new Float32Array([w * (c.probs[0] - (1 - ex.label)), w * (c.probs[1] - ex.label)]);

    // Dense2 grad + backprop into relu1d
    const dRelu1d = new Float32Array(H1);
    for (let o = 0; o < 2; o++) {
      gDense2b[o] += dLogits[o];
      for (let i = 0; i < H1; i++) {
        gDense2[o * H1 + i] += dLogits[o] * c.relu1d[i];
        dRelu1d[i] += params.dense2[o * H1 + i] * dLogits[o];
      }
    }

    // ReLU back through dense1
    const dDense1 = new Float32Array(H1);
    for (let i = 0; i < H1; i++) dDense1[i] = c.relu1d[i] > 0 ? dRelu1d[i] : 0;

    // Dense1 grad + backprop into flat
    const dFlat = new Float32Array(FLAT);
    for (let o = 0; o < H1; o++) {
      gDense1b[o] += dDense1[o];
      for (let i = 0; i < FLAT; i++) {
        gDense1[o * FLAT + i] += dDense1[o] * c.flat[i];
        dFlat[i] += params.dense1[o * FLAT + i] * dDense1[o];
      }
    }

    // dFlat[0..95] = grad into pool1; dFlat[96..97] are attribute grads (no params).
    const dPool1 = dFlat.subarray(0, F1 * POOLED * POOLED);

    // Unpool: route each pool gradient back to its argmax cell in relu1.
    const dRelu1 = new Float32Array(F1 * IN * IN);
    for (let ch = 0; ch < F1; ch++) {
      for (let pr = 0; pr < POOLED; pr++) {
        for (let pc = 0; pc < POOLED; pc++) {
          const grad = dPool1[ch * POOLED * POOLED + pr * POOLED + pc];
          const aIdx = c.poolArgmax[ch * POOLED * POOLED + pr * POOLED + pc];
          // ReLU gate
          if (c.conv1Out[ch * IN * IN + aIdx] > 0) {
            dRelu1[ch * IN * IN + aIdx] = grad;
          }
        }
      }
    }

    // Conv1 weight + bias grad (input = x [IN*IN], grad = dRelu1 [F1, IN, IN])
    for (let f = 0; f < F1; f++) {
      for (let kr = 0; kr < 3; kr++) {
        for (let kc = 0; kc < 3; kc++) {
          let gw = 0;
          let gb = 0;
          for (let r = 0; r < IN; r++) {
            for (let col = 0; col < IN; col++) {
              const g = dRelu1[f * IN * IN + r * IN + col];
              if (g === 0) continue;
              gb += g; // bias grad = sum of output grads (applied once per filter)
              const ir = r + kr - 1;
              const ic = col + kc - 1;
              if (ir >= 0 && ir < IN && ic >= 0 && ic < IN) {
                gw += g * c.x[ir * IN + ic];
              }
            }
          }
          gConv1[f * 9 + kr * 3 + kc] += gw;
          if (kr === 0 && kc === 0) gConv1b[f] += gb;
        }
      }
    }
  }

  // Apply averaged gradients.
  const b = batch.length || 1;
  for (let i = 0; i < params.conv1.length; i++) params.conv1[i] -= (lr * gConv1[i]) / b;
  for (let i = 0; i < F1; i++) params.conv1b[i] -= (lr * gConv1b[i]) / b;
  for (let i = 0; i < params.dense1.length; i++) params.dense1[i] -= (lr * gDense1[i]) / b;
  for (let i = 0; i < H1; i++) params.dense1b[i] -= (lr * gDense1b[i]) / b;
  for (let i = 0; i < params.dense2.length; i++) params.dense2[i] -= (lr * gDense2[i]) / b;
  for (let i = 0; i < 2; i++) params.dense2b[i] -= (lr * gDense2b[i]) / b;

  return { loss: totalLoss / b, acc: correct / b };
}

export function trainCNN(
  params: CNNParams,
  data: TrainingExample[],
  epochs: number,
  lr: number,
  onEpoch?: (h: TrainHistory) => void,
): TrainHistory[] {
  const history: TrainHistory[] = [];
  for (let e = 0; e < epochs; e++) {
    const idx = data.map((_, i) => i);
    for (let i = idx.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [idx[i], idx[j]] = [idx[j], idx[i]];
    }
    const bs = 8;
    let epLoss = 0;
    let epAcc = 0;
    let nB = 0;
    for (let s = 0; s < idx.length; s += bs) {
      const batch = idx.slice(s, s + bs).map((i) => data[i]);
      if (batch.length === 0) continue;
      const r = trainStep(params, batch, lr);
      epLoss += r.loss;
      epAcc += r.acc;
      nB++;
    }
    const h: TrainHistory = { epoch: e + 1, loss: epLoss / Math.max(1, nB), acc: epAcc / Math.max(1, nB) };
    history.push(h);
    onEpoch?.(h);
  }
  return history;
}
