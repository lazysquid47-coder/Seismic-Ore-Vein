// Subsurface reconstruction + CNN-based ore-vein inference.
//
// Two stages, mirroring the cited work:
//   1. Velocity tomography (IEEE 10974575) — convert travel-time picks into a
//      2-D seismic-velocity map of the region, revealing boundaries between
//      underground geological materials.
//   2. CNN classification (IEEE 10921706 + 10457542) — a genuinely trained CNN
//      (see engine/cnn.ts) classifies 9x9 velocity patches as vein / background.
//      The ground-truth labels come from the known vein geometry embedded by
//      the tomography stage — the same "train on labelled synthetic/field data"
//      strategy the cited CNN papers use.

import type { Arrival } from './processing';
import { initParams, trainCNN, classify, type CNNParams, type Patch, type TrainingExample, type TrainHistory } from './cnn';

export type RegionSpec = {
  id: string;
  name: string;
  widthKm: number;
  depthKm: number;
  cols: number;
  rows: number;
  baseRock: 'sediment' | 'basalt' | 'granite';
};

export type VeinCandidate = {
  row: number;
  col: number;
  xKm: number;
  depthKm: number;
  velocityKms: number;
  contrast: number; // velocity contrast vs surrounding rock
  oreConfidence: number; // CNN softmax probability of vein class
  vpVsRatio: number; // Vp/Vs ratio — denser ores raise this
  impedance: number; // acoustic impedance rho*Vp
  lithology: string;
  status: 'primary' | 'secondary' | 'low';
};

export type VelocityMap = {
  region: RegionSpec;
  grid: Float32Array; // rows * cols, row-major
  mask: Uint8Array; // ground-truth vein mask (0/1) — training labels
  arrivals: Arrival[];
  candidates: VeinCandidate[];
  cnn: CNNParams;
  trainHistory: TrainHistory[];
};

// Background Vp / Vs per host rock (km/s). Vp/Vs ratio is a real geophysical
// discriminant: dense sulphide/oxide ore raises Vp/Vs above the host value.
const BASE: Record<RegionSpec['baseRock'], { vp: number; vs: number; rho: number }> = {
  sediment: { vp: 2.6, vs: 1.3, rho: 2.3 },
  basalt: { vp: 5.4, vs: 3.0, rho: 2.9 },
  granite: { vp: 6.0, vs: 3.5, rho: 2.7 },
};

function softmaxLocal(xs: number[]): number[] {
  const m = Math.max(...xs);
  const exps = xs.map((x) => Math.exp(x - m));
  const s = exps.reduce((a, b) => a + b, 0);
  return exps.map((e) => e / s);
}

// Build the background velocity grid from arrival picks (travel-time inversion
// surrogate). Returns the grid BEFORE the vein is embedded.
function buildBackground(region: RegionSpec, arrivals: Arrival[]): Float32Array {
  const { rows, cols } = region;
  const grid = new Float32Array(rows * cols);
  const base = BASE[region.baseRock];
  const pResid = arrivals.find((a) => a.phase === 'P')?.amplitude ?? 0.5;
  const sResid = arrivals.find((a) => a.phase === 'S')?.amplitude ?? 0.4;
  for (let r = 0; r < rows; r++) {
    for (let c = 0; c < cols; c++) {
      const depthFrac = r / (rows - 1);
      const lateralFrac = c / (cols - 1);
      const latPerturb = 0.12 * Math.sin(lateralFrac * Math.PI * (1 + pResid)) * (0.5 + sResid);
      grid[r * cols + c] = base.vp + depthFrac * 1.8 + latPerturb;
    }
  }
  // Smooth (diffusion) — gives a tomographic look.
  for (let pass = 0; pass < 2; pass++) {
    const tmp = new Float32Array(grid.length);
    for (let r = 0; r < rows; r++) {
      for (let c = 0; c < cols; c++) {
        let sum = 0;
        let count = 0;
        for (let dr = -1; dr <= 1; dr++) {
          for (let dc = -1; dc <= 1; dc++) {
            const rr = r + dr;
            const cc = c + dc;
            if (rr < 0 || rr >= rows || cc < 0 || cc >= cols) continue;
            sum += grid[rr * cols + cc];
            count++;
          }
        }
        tmp[r * cols + c] = sum / count;
      }
    }
    grid.set(tmp);
  }
  return grid;
}

// Embed a high-velocity dipping vein into the grid AND record its mask (the
// ground-truth labels the CNN trains on).
function embedVein(
  grid: Float32Array,
  region: RegionSpec,
  arrivals: Arrival[],
  seed: number,
): Uint8Array {
  const { rows, cols } = region;
  const mask = new Uint8Array(rows * cols);
  const base = BASE[region.baseRock];
  const refl = arrivals.find((a) => a.phase === 'reflection');
  const sPhase = arrivals.find((a) => a.phase === 'S');
  const ref = refl ?? sPhase ?? arrivals[0];

  let h = seed >>> 0;
  const rng = () => {
    h = (Math.imul(h ^ (h >>> 15), 0x85ebca6b) | 0) ^ (h >>> 13);
    return ((h ^ (h >>> 16)) >>> 0) / 4294967296;
  };

  const colCenter = Math.min(
    cols - 4,
    Math.max(4, Math.floor(cols * (0.3 + (ref ? ref.time : 2) * 0.04 + rng() * 0.1))),
  );
  const rowCenter = Math.min(
    rows - 4,
    Math.max(4, Math.floor(rows * (0.45 + rng() * 0.2))),
  );
  const veinRows = Math.max(2, Math.floor(rows * 0.14));
  const veinCols = Math.max(3, Math.floor(cols * 0.18));
  const dip = (rng() - 0.5) * 0.6;
  const oreVp = base.vp * 1.18 + 0.6;

  for (let r = 0; r < veinRows; r++) {
    for (let c = 0; c < veinCols; c++) {
      const dr = Math.round(r + dip * c);
      const rr = rowCenter - Math.floor(veinRows / 2) + dr;
      const cc = colCenter - Math.floor(veinCols / 2) + c;
      if (rr < 0 || rr >= rows || cc < 0 || cc >= cols) continue;
      const taper = Math.exp(-((r - veinRows / 2) ** 2) / (veinRows * 0.6));
      const idx = rr * cols + cc;
      grid[idx] = Math.max(grid[idx], base.vp + (oreVp - base.vp) * taper);
      if (taper > 0.4) mask[idx] = 1;
    }
  }
  return mask;
}

// Add tomographic noise so the recovered map is imperfect (realistic).
function addNoise(grid: Float32Array, seed: number): void {
  let h = seed ^ 0x9e3779b9;
  for (let i = 0; i < grid.length; i++) {
    h = (Math.imul(h ^ (h >>> 15), 0x85ebca6b) | 0) ^ (h >>> 13);
    const n = ((h ^ (h >>> 16)) >>> 0) / 4294967296;
    grid[i] += (n - 0.5) * 0.05;
  }
}

// Extract a normalised 9x9 patch centred at (r,c), plus two geophysical
// attributes (Vp/Vs ratio, acoustic impedance) for the dense-layer features.
function extractPatch(
  grid: Float32Array,
  region: RegionSpec,
  r: number,
  c: number,
): Patch | null {
  const { rows, cols } = region;
  const half = 4; // 9x9
  if (r - half < 0 || r + half >= rows || c - half < 0 || c + half >= cols) return null;
  const g = new Float32Array(81);
  let mn = Infinity;
  let mx = -Infinity;
  for (let dr = -half; dr <= half; dr++) {
    for (let dc = -half; dc <= half; dc++) {
      const v = grid[(r + dr) * cols + (c + dc)];
      const idx = (dr + half) * 9 + (dc + half);
      g[idx] = v;
      if (v < mn) mn = v;
      if (v > mx) mx = v;
    }
  }
  // Normalise to [0,1] so the CNN sees consistent input.
  const range = Math.max(1e-6, mx - mn);
  for (let i = 0; i < 81; i++) g[i] = (g[i] - mn) / range;
  const centerVp = grid[r * cols + c];
  const base = BASE[region.baseRock];
  // Vp/Vs ratio — ore raises Vp relative to Vs, so the patch's relative
  // velocity maps to an elevated Vp/Vs estimate.
  const vsEst = base.vs + (centerVp - base.vp) * 0.55;
  const vpVs = centerVp / Math.max(0.5, vsEst);
  const rho = base.rho + (centerVp - base.vp) * 0.18;
  const impedance = rho * centerVp;
  return { grid: g, vpVs, impedance };
}

export function reconstructVelocity(
  region: RegionSpec,
  arrivals: Arrival[],
  seed: number,
): VelocityMap {
  const { rows, cols, widthKm, depthKm } = region;

  // 1. Background velocity from travel-time picks.
  const grid = buildBackground(region, arrivals);

  // 2. Embed the vein + record ground-truth mask (the labels).
  const mask = embedVein(grid, region, arrivals, seed);

  // 3. Tomographic noise.
  addNoise(grid, seed);

  // 4. Build the labelled training set from 9x9 patches.
  const data: TrainingExample[] = [];
  for (let r = 4; r < rows - 4; r++) {
    for (let c = 4; c < cols - 4; c++) {
      const patch = extractPatch(grid, region, r, c);
      if (!patch) continue;
      // Label = 1 if the patch centre is inside the vein mask, with a small
      // positive sampling from the surrounding ring so the CNN sees both
      // classes in balanced proportion.
      const label: 0 | 1 = mask[r * cols + c] === 1 ? 1 : 0;
      data.push({ patch, label });
    }
  }
  // Balance classes: keep all vein patches, oversample them, and pair with
  // an equal number of background patches.
  const veins = data.filter((d) => d.label === 1);
  const bgs = data.filter((d) => d.label === 0);
  // Oversample vein patches by duplication so the CNN sees enough positives.
  const oversampledVeins = [...veins, ...veins, ...veins];
  const balanced = [...oversampledVeins];
  const bgSample = bgs.sort(() => Math.random() - 0.5).slice(0, Math.max(oversampledVeins.length, 120));
  balanced.push(...bgSample);

  // 5. Initialise + train the CNN.
  const rng = () => Math.random();
  const cnn = initParams(rng);
  const trainHistory = trainCNN(cnn, balanced, 80, 0.15);

  // 6. Slide the trained CNN over every cell, collect vein predictions.
  const candidates: VeinCandidate[] = [];
  const cellW = widthKm / cols;
  const depths = Array.from({ length: rows }, (_, r) => (r / (rows - 1)) * depthKm);
  const base = BASE[region.baseRock];

  for (let r = 4; r < rows - 4; r++) {
    for (let c = 4; c < cols - 4; c++) {
      const patch = extractPatch(grid, region, r, c);
      if (!patch) continue;
      const { veinProb } = classify(cnn, patch);
      if (veinProb < 0.5) continue;

      const centerVp = grid[r * cols + c];
      // local contrast
      let neigh = 0;
      let cnt = 0;
      for (let dr = -1; dr <= 1; dr++) {
        for (let dc = -1; dc <= 1; dc++) {
          if (dr === 0 && dc === 0) continue;
          neigh += grid[(r + dr) * cols + (c + dc)];
          cnt++;
        }
      }
      const contrast = centerVp - neigh / cnt;

      const lithology =
        centerVp > base.vp + 1.0
          ? 'Volcanic / massive-sulphide host (favourable)'
          : centerVp > base.vp + 0.4
          ? 'Crystalline basement'
          : 'Sedimentary cover';

      candidates.push({
        row: r,
        col: c,
        xKm: c * cellW,
        depthKm: depths[r],
        velocityKms: centerVp,
        contrast,
        oreConfidence: veinProb,
        vpVsRatio: patch.vpVs,
        impedance: patch.impedance,
        lithology,
        status: veinProb > 0.7 ? 'primary' : veinProb > 0.55 ? 'secondary' : 'low',
      });
    }
  }

  // 7. Non-maximum suppression — collapse nearby detections into one vein.
  candidates.sort((a, b) => b.oreConfidence - a.oreConfidence);
  const kept: VeinCandidate[] = [];
  for (const cand of candidates) {
    let tooClose = false;
    for (const k of kept) {
      const dr = cand.row - k.row;
      const dc = cand.col - k.col;
      if (dr * dr + dc * dc < 9) {
        tooClose = true;
        break;
      }
    }
    if (!tooClose) kept.push(cand);
  }
  kept.forEach((c, i) => {
    c.status = i === 0 ? 'primary' : i < 3 ? 'secondary' : 'low';
  });

  return { region, grid, mask, arrivals, candidates: kept.slice(0, 6), cnn, trainHistory };
}

// Colour map for velocity rendering (a perceptual, seismic-friendly ramp).
export function velocityColor(vp: number, minVp: number, maxVp: number): [number, number, number] {
  const t = Math.max(0, Math.min(1, (vp - minVp) / (maxVp - minVp)));
  const stops: [number, [number, number, number]][] = [
    [0.0, [10, 18, 40]],
    [0.3, [18, 60, 78]],
    [0.55, [20, 130, 120]],
    [0.78, [240, 180, 60]],
    [1.0, [244, 63, 94]],
  ];
  for (let i = 0; i < stops.length - 1; i++) {
    const [t0, c0] = stops[i];
    const [t1, c1] = stops[i + 1];
    if (t >= t0 && t <= t1) {
      const f = (t - t0) / (t1 - t0);
      return [
        Math.round(c0[0] + (c1[0] - c0[0]) * f),
        Math.round(c0[1] + (c1[1] - c0[1]) * f),
        Math.round(c0[2] + (c1[2] - c0[2]) * f),
      ];
    }
  }
  return stops[stops.length - 1][1];
}
