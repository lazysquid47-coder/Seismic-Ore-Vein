// Waveform synthesis — generates a synthetic earthquake seismogram.
// Paper context: the STEAD dataset (IEEE 8871127) provides ~1.2M local earthquake
// waveforms; we synthesize equivalent-looking waveforms so the pipeline has a
// genuine seismic signal to process rather than a pure sine wave.

export type WaveParams = {
  magnitude: number; // Mw 1.0 - 7.0
  distanceKm: number; // epicentre-to-receiver offset
  rockType: 'sediment' | 'basalt' | 'granite' | 'ore_host';
  samplingRate: number; // Hz
  durationS: number; // seconds
};

export type Trace = {
  samples: Float32Array;
  samplingRate: number;
  durationS: number;
  n: number;
};

// Deterministic PRNG so the same parameters reproduce the same waveform.
function mulberry32(seed: number) {
  let a = seed >>> 0;
  return () => {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

function hashParams(p: WaveParams): number {
  let h = 2166136261;
  const str = `${p.magnitude}|${p.distanceKm}|${p.rockType}|p.sr${p.samplingRate}|${p.durationS}`;
  for (let i = 0; i < str.length; i++) {
    h ^= str.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return h >>> 0;
}

// P- and S-wave apparent velocities (km/s) for host media. An "ore_host" zone
// has higher Vp than sediment and produces stronger reflections at boundaries.
const HOST_VELOCITIES: Record<WaveParams['rockType'], { vp: number; vs: number }> = {
  sediment: { vp: 2.4, vs: 1.2 },
  basalt: { vp: 5.2, vs: 3.0 },
  granite: { vp: 6.0, vs: 3.5 },
  ore_host: { vp: 6.8, vs: 3.9 },
};

// Ricker (Mexican-hat) wavelet — standard seismic source pulse.
function ricker(t: number, f0: number): number {
  const arg = Math.PI * f0 * t;
  const a = 1 - 2 * arg * arg;
  return a * Math.exp(-arg * arg);
}

export function generateSeismogram(params: WaveParams): Trace {
  const sr = params.samplingRate;
  const n = Math.floor(sr * params.durationS);
  const samples = new Float32Array(n);
  const rng = mulberry32(hashParams(params));
  const v = HOST_VELOCITIES[params.rockType];

  // Arrival times of body-wave phases (seconds).
  const tP = params.distanceKm / v.vp;
  const tS = params.distanceKm / v.vs;
  const tSurface = params.distanceKm / 3.0; // surface wave ~3 km/s

  // Amplitude scales with magnitude (log10 of radiated energy).
  const magScale = Math.pow(10, params.magnitude - 4);
  const pAmp = 0.35 * magScale;
  const sAmp = 0.7 * magScale;
  const surfAmp = 0.5 * magScale;

  // Dominant frequency content (Hz).
  const fP = 8 + rng() * 4;
  const fS = 4 + rng() * 2;
  const fSurf = 0.8 + rng() * 0.6;

  // Reflection coefficient at an embedded vein boundary — higher for ore_host.
  const reflCoef = params.rockType === 'ore_host' ? 0.42 : 0.18;
  const tRefl = tP + params.distanceKm / v.vp * 0.45 + rng() * 0.15;
  const reflAmp = pAmp * reflCoef;

  for (let i = 0; i < n; i++) {
    const t = i / sr;
    let s = 0;

    // P-wave train: compact, high-frequency.
    if (t > tP) {
      const dt = t - tP;
      s += pAmp * ricker(dt - 0.05, fP) * Math.exp(-dt * 6);
    }
    // S-wave train: lower frequency, longer coda.
    if (t > tS) {
      const dt = t - tS;
      s += sAmp * ricker(dt - 0.08, fS) * Math.exp(-dt * 3.5);
    }
    // Surface wave: low frequency, slow decay.
    if (t > tSurface) {
      const dt = t - tSurface;
      s += surfAmp * Math.sin(2 * Math.PI * fSurf * dt) * Math.exp(-dt * 0.6);
    }
    // Reflected phase from an embedded boundary (the signature we hunt for).
    if (t > tRefl) {
      const dt = t - tRefl;
      s += reflAmp * ricker(dt - 0.04, fP * 0.9) * Math.exp(-dt * 9);
    }

    // Background microseismic noise + sensor self-noise.
    const noise = (rng() - 0.5) * 0.08 * (1 + params.magnitude * 0.2);
    samples[i] = s + noise;
  }

  return { samples, samplingRate: sr, durationS: params.durationS, n };
}

// Downsample a trace to a target number of points for waveform display.
export function decimate(trace: Trace, target: number): number[] {
  if (trace.n <= target) return Array.from(trace.samples);
  const step = trace.n / target;
  const out: number[] = [];
  for (let i = 0; i < target; i++) {
    out.push(trace.samples[Math.floor(i * step)]);
  }
  return out;
}
